<template>
    <v-layout>
      <h1>Daftar Menu</h1>
      <v-navigation-drawer
        class="bg-blue-darken-3"
        permanent
      >
        <v-list >
          <router-link to="/" style="text-decoration: none; color: white;"><v-list-item>Pesan Terakhir <v-icon icon="mdi-logout"></v-icon></v-list-item></router-link>
        </v-list>

        <template v-slot:append>
          <div class="pa-2">
            <p>Kirim Pesan Ke:</p>
            <v-text-field type="text" label="username teman..."></v-text-field>
          </div>
        </template>
      </v-navigation-drawer>
    </v-layout>
</template>